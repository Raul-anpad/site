====================================================================================================
Darcy Ripper - Console Mode v. 1.0

In order to start the Darcy Ripper in console mode, run the "java -jar darcy-console.jar" command
in the terminal.

Darcy Ripper - Console Mode works with the DJP files. Thus, in order to download web resources
a DJP file must be edited first with the Darcy Ripper application.

The following commands are available:
  * h       - Prints the tool' help;
  * djp     - Specifies the DJP file to be processed;
  * verbose - Specifies that the tool must run in the verbose mode.
====================================================================================================